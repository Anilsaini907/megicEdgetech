export type Task = {
  name: string,
  due: Date,
  complete: boolean,
  description: string,
}
