// No need to change this file
import { Routes } from '@angular/router';

export const routes: Routes = [];
