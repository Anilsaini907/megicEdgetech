import { Injectable } from '@angular/core';
import { Task, TaskAndId } from '../task-types';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable,of } from 'rxjs';
import { catchError, tap} from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class TaskService {
  private apiUrl = 'http://localhost:5200/api/tasks'
  private tasksSubject = new BehaviorSubject<any>([]);
  tasks$ = this.tasksSubject.asObservable();

  constructor(private http: HttpClient) { }

  getTasks(): Observable<any> {
    return this.http.get<any>(this.apiUrl).pipe(
      catchError(() => of([]))
    );
  }

  refreshTasks() {
    this.getTasks().subscribe(tasks => this.tasksSubject.next(tasks));
  }
  updateTask(id: string, task: Task): Observable<any> {  
   return this.http.put(`${this.apiUrl}/${id}`, { task });  
  } 

  createTask(newTask: Task): Observable<any> {
    return this.http.post(this.apiUrl, { task: newTask })
  }

  deleteTask(id: string): Observable<any> {
   return this.http.delete(`${this.apiUrl}/${id}`)
  }
}
