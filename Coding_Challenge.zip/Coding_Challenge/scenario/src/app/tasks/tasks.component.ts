// No need to change this file
import { Component } from '@angular/core';

import { TaskDisplayComponent } from './task-display/task-display.component';


@Component({
  selector: 'app-tasks',
  standalone: true,
  imports: [TaskDisplayComponent],
  templateUrl: './tasks.component.html',
})
export class TasksComponent {

}
