// No need to change this file
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TaskService } from '../task.service';
import { TaskAndId } from '../../task-types';
import { Observable, of } from 'rxjs';
import { AsyncPipe,  DatePipe } from '@angular/common';
import { ButtonModule } from 'primeng/button';
import { TableModule } from 'primeng/table';
import { TagModule } from 'primeng/tag'; 
import { catchError, map} from 'rxjs/operators';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { DialogModule } from 'primeng/dialog';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { CalendarModule } from 'primeng/calendar';
import { CheckboxModule } from 'primeng/checkbox';
import { InputTextModule } from 'primeng/inputtext';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';

interface Task {
  name: string;
  due: Date;
  description: string;
  complete: boolean; 
}
@Component({
  selector: 'app-task-display',
  standalone: true,
  imports: [AsyncPipe,ButtonModule,TableModule,TagModule,DatePipe,ProgressSpinnerModule,DialogModule,
    FormsModule,
    CalendarModule,
    CheckboxModule ,ButtonModule,
    DialogModule,
    InputTextModule,CommonModule,ReactiveFormsModule,ToastModule
    ],
    providers: [MessageService],
  templateUrl: './task-display.component.html',
  styleUrls: ['./task-display.component.css']
})


export class TaskDisplayComponent  {
  taskForm: FormGroup;
  tasks: TaskAndId[] = []; 
  displayDialog = false;
  isEditMode = false;
  currentTaskId: string | null = null;
  totalRecords:number=0;

  constructor(private taskService: TaskService,private fb: FormBuilder,private messageService: MessageService) {
    this.taskForm = this.fb.group({
      name: ['', Validators.required],
      due: [new Date(), Validators.required],
      description: ['', Validators.required],
      complete: [false, Validators.required]
    });
    this.loadTasks();
  }
  loadTasks() {
    this.taskService.getTasks().subscribe({
      next: (res) => {this.tasks = res || [],
        this.totalRecords=res.length},
      error: (err) => {
        console.error('Error loading tasks:', err);
        this.tasks = [];
      }
    });
  }
  showAddDialog() {
    this.isEditMode = false;
    this.currentTaskId = null;
    this.taskForm.reset({
      name: '',
      due: new Date(),
      description: '',
      complete: false
    });
    this.displayDialog = true;
  }

 
  editTask(task: TaskAndId) {
    this.isEditMode = true;
    this.currentTaskId = task._id;
    this.taskForm.patchValue({
      name: task.name,
      due: new Date(task.due),
      description: task.description,
      complete: task.complete
    });
    this.displayDialog = true;
  }

  saveTask() {
    if (this.taskForm.valid) {
      const taskData: Task = this.taskForm.value;
  
      if (this.isEditMode && this.currentTaskId) {
        this.taskService.updateTask(this.currentTaskId, taskData).subscribe({
          next: () => {
            this.messageService.add({
              severity: 'success',
              summary: 'Success',
              detail: 'Task updated successfully'
            });
            this.displayDialog = false;
            this.loadTasks();
          },
          error: (err: any) => {
            console.error('Error updating task:', err);
            this.messageService.add({
              severity: 'error',
              summary: 'Error',
              detail: 'Failed to update task'
            });
          }
        });
      } else {
        this.taskService.createTask(taskData).subscribe({
          next: () => {
            this.messageService.add({
              severity: 'success',
              summary: 'Success',
              detail: 'Task created successfully'
            });
            this.displayDialog = false;
            this.loadTasks();
          },
          error: (err) => {
            console.error('Error adding task:', err);
            this.messageService.add({
              severity: 'error',
              summary: 'Error',
              detail: 'Failed to create task'
            });
          }
        });
      }
    } else {
      
      this.messageService.add({
        severity: 'warn',
        summary: 'Validation',
        detail: 'Please fill all required fields'
      });
    }
  }

  deleteTask(taskId: string) {
    this.taskService.deleteTask(taskId).subscribe({
      next: () => this.loadTasks(),
      error: (err) => console.error('Error deleting task:', err)
    });
  }

  getStatusSeverity(complete: boolean) {
    return complete ? 'success' : 'warning';
  }
}
