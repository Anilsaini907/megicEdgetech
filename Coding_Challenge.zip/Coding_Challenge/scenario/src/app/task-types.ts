export type Task = {
  name: string;
  due: Date;
  complete: boolean; // Changed from boolean | undefined
  description: string;
}

export type TaskAndId = Task & { _id: string }
